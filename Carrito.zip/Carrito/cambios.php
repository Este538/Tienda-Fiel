<?php 
  
    if(isset($_POST['submit'])){ 
          
        foreach($_POST['cantidad'] as $key => $val) { 
            if($val==0) { 
                unset($_SESSION['cambios'][$key]); 
            }else{ 
                $_SESSION['cambios'][$key]['cantidad']=$val; 
            } 
        } 
          
    } 
  
?> 
  
<h1>View cart</h1> 
<a href="carrito.php?page=catalogo">Go back to the products page.</a> 
<form method="post" action="carrito.php?page=cambios"> 
      
    <table> 
          
        <tr> 
            <th>Nombre</th> 
            <th>Cantidad</th> 
            <th>Precio</th> 
            <th>Precio total</th> 
        </tr> 
          
        <?php 
             if(isset($_POST['submit'])){ 
          
                foreach($_POST['cantidad'] as $key => $val) { 
                    if($val==0) { 
                        unset($_SESSION['cambios'][$key]); 
                    }else{ 
                        $_SESSION['cambios'][$key]['cantidad']=$val; 
                    } 
                } 
              
            } 
          
            $sql="SELECT * FROM productos WHERE ClaveProducto IN ("; 
                      
                    include("conexion.php");
                    session_start();
                    $value = $_SESSION['cambios'];
                    foreach($value as $id => $value) { 
                        $sql.=$id.","; 
                    } 
                      
                    $sql=substr($sql, 0, -1).") ORDER BY name ASC"; 
                    $query=mysqli_query($conn,$sql); 
                    $totalprice=0; 
                    while($row=mysqli_fetch_array($query)){ 
                        $subtotal=$_SESSION['cambios'][$row['ClaveProducto']]['cantidad']*$row['Precio']; 
                        $totalprice+=$subtotal; 
                    ?> 
                        <tr> 
                            <td><?php echo $row['Nombre'] ?></td> 
                            <td><input type="text" name="cantidad[<?php echo $row['ClaveProducto'] ?>]" size="5" value="<?php echo $_SESSION['cambios'][$row['ClaveProducto']]['cantidad'] ?>" /></td> 
                            <td><?php echo $row['Precio'] ?>$</td> 
                            <td><?php echo $_SESSION['cambios'][$row['ClaveProducto']]['cantidad']*$row['Precio'] ?>$</td> 
                        </tr> 
                    <?php 
                          
                    } 
        ?> 
                    <tr> 
                        <td colspan="4">Total Price: <?php echo $totalprice ?></td> 
                    </tr> 
          
    </table> 
    <br /> 
    <button type="submit" name="submit">Subir al Carro</button> 
</form> 
<br /> 
<p>To remove an item set its quantity to 0. </p>