<?php 
  
  $servidor = "localhost";
  $usuario = "root";
  $contrasena = "";
  $basedatos = "orange"; 
      
    // conectar a mysql 
      
   $conn =  mysqli_connect($servidor, $usuario, $contrasena, $basedatos);

   if(!$conn)
        die("Lo sentimos, no se puede conectar a la base de datos."); 
      

  
?>