<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd"> 
<html xmlns="http://www.w3.org/1999/xhtml"> 
<head> 
      
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" /> 
    <link rel="stylesheet" href="css/reset.css" /> 
    <link rel="stylesheet" href="css/style.css" /> 
      
  
    <title>Shopping Cart</title> 
  
  
</head> 
  
<body> 
      
<?php 
  
    if(isset($_GET['action']) && $_GET['action']=="add"){ 
          
        $id=intval($_GET['id']); 
        include("conexion.php");
          
        if(isset($_SESSION['cambios'][$id])){ 
              
            $_SESSION['cambios'][$id]['cantidad']++; 
              
        }else{ 
              
            $sql_s="SELECT * FROM productos 
                WHERE ClaveProducto={$id}"; 
            $query_s=mysqli_query($conn,$sql_s); 
            if(mysqli_num_rows($query_s)!=0){ 
                $row_s=mysqli_fetch_array($query_s); 
                  
                $_SESSION['cambios'][$row_s['ClaveProducto']]=array( 
                        "cantidad" => 1, 
                        "precio" => $row_s['Precio'] 
                    ); 
                  
                  
            }else{ 
                  
                $message="El producto no va"; 
                  
            } 
              
        } 
          
    } 
  
?> 
    <h1>Lista de Productos</h1> 
    <?php 
        if(isset($message)){ 
            echo "<h2>$message</h2>"; 
        } 
    ?> 
    <table> 
        <tr> 
            <th>Proveedor</th> 
            <th>Producto</th> 
            <th>Precio</th> 
            <th>Action</th> 
        </tr> 
          
        <?php 
            include("conexion.php");
            $sql="SELECT * FROM productos"; 
            $query=mysqli_query($conn,$sql); 
              
            while ($row=mysqli_fetch_array($query)) { 
                  
        ?> 
            <tr> 
                <td><?php echo $row['NProveedor'] ?></td> 
                <td><?php echo $row['NProducto'] ?></td> 
                <td><?php echo $row['Precio'] ?>$</td> 
                <td><a href="catalogo.php?page=catalogo&action=add&id=<?php echo $row['ClaveProducto'] ?>">Add to cart</a></td> 
            </tr> 
        <?php 
                  
            } 
          
        ?> 
          
    </table>
  
</body> 
</html>