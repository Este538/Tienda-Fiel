<?php 
    session_start(); 
    require("conexion.php"); 
    if(isset($_GET['page'])){ 
          
        $pages=array("catalogo", "cambios"); 
          
        if(in_array($_GET['page'], $pages)) { 
              
            $_page=$_GET['page']; 
              
        }else{ 
              
            $_page="catalogo"; 
              
        } 
          
    }else{ 
          
        $_page="catalogo"; 
          
    } 
  
?> 
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd"> 
<html xmlns="http://www.w3.org/1999/xhtml"> 
<head> 
      
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" /> 
    <link rel="stylesheet" href="css/reset.css" /> 
    <link rel="stylesheet" href="css/style.css" /> 
      
  
    <title>Shopping Cart</title> 
  
  
</head> 
  
<body> 
      
    <div id="container"> 
  
        <div id="main"> 
              
            <?php require($_page.".php"); ?> 
  
        </div><!--end of main--> 
          
        <div id="sidebar"> 
        <h1>Carrito</h1> 
        <?php 
            include("conexion.php");
            if(isset($_SESSION['cambios'])){ 
          
            $sql="SELECT * FROM productos WHERE ClaveProducto IN ("; 
          
            foreach($_SESSION['cambios'] as $id => $value) { 
                $sql.=$id.","; 
            } 
          
            $sql=substr($sql, 0, -1).") ORDER BY name ASC"; 
            $query=mysqli_query($conn, $sql); 
            while($row=mysqli_fetch_array($query)){ 
              
            ?> 
                <p><?php echo $row['name'] ?> x <?php echo $_SESSION['cambios'][$row['Clave_Producto']]['cantidad'] ?></p> 
            <?php 
              
            } 
        ?> 
            <hr /> 
            <a href="carrito.php?page=cambios">Ir al carrito</a> 
        <?php 
          
        }else{ 
            
            echo "<p> Carrito sin nada. Por favor agregue compras.</p>"; 
          
    } 
  
    ?>
        </div><!--end of sidebar--> 
  
    </div><!--end container--> 
  
</body> 
</html>